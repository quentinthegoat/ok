import { useState, useEffect, useCallback } from 'react'
import {
  Home, Heart, Briefcase, DollarSign, BookOpen,
  CheckCircle2, Circle, ChevronRight, ArrowUpRight,
  Plus, Trash2, Droplets, Dumbbell
} from 'lucide-react'

// ─── TOKENS ──────────────────────────────────────────────────────────────────
const C = {
  paper:     '#f6f3ec',
  paperDeep: '#efece4',
  paperCard: '#fdfcf8',
  ink:       '#0d0d0d',
  inkSoft:   '#3d3d3d',
  muted:     '#8a8580',
  mutedSoft: '#c4bfb8',
  rule:      'rgba(26,26,26,0.1)',
  ruleSoft:  'rgba(26,26,26,0.06)',
  accent:    '#7d2a1c',
  accentBg:  'rgba(125,42,28,0.08)',
  positive:  '#2d4a2b',
  amber:     '#9a6a18',
}
const FONT  = `'DM Sans', sans-serif`
const SERIF = `'Fraunces', Georgia, serif`
const MONO  = `'JetBrains Mono', monospace`

// ─── LOCAL STORAGE ────────────────────────────────────────────────────────────
function usePersist(key, init) {
  const [val, setVal] = useState(() => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : init }
    catch { return init }
  })
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(val)) } catch {} }, [key, val])
  return [val, setVal]
}

// ─── SEED DATA ────────────────────────────────────────────────────────────────
const SEED_GOALS = [
  { id: 1, text: 'Ship simulator v0.4 to investors', done: false, priority: 'P0', cat: 'Build' },
  { id: 2, text: 'Strength session — push day',       done: false, priority: 'P1', cat: 'Health' },
  { id: 3, text: 'Review weekly P&L',                 done: false, priority: 'P1', cat: 'Finance' },
  { id: 4, text: 'Post on TikTok',                    done: false, priority: 'P1', cat: 'Brand' },
  { id: 5, text: '20 pages — current book',           done: false, priority: 'P2', cat: 'Mind' },
  { id: 6, text: 'Cold exposure — 3 min',             done: false, priority: 'P2', cat: 'Health' },
]

const SEED_SUPPS = [
  { id: 1, name: 'Caffeine',    dose: '200 mg',  window: '07:00',    taken: false },
  { id: 2, name: 'L-Theanine', dose: '200 mg',  window: '07:00',    taken: false },
  { id: 3, name: 'Vitamin D3', dose: '5000 IU', window: '08:00',    taken: false },
  { id: 4, name: 'Omega-3',    dose: '2 g',     window: '08:00',    taken: false },
  { id: 5, name: 'Creatine',   dose: '5 g',     window: 'Post-W/O', taken: false },
  { id: 6, name: 'Magnesium',  dose: '400 mg',  window: '21:00',    taken: false },
  { id: 7, name: 'Ashwagandha',dose: '600 mg',  window: '21:00',    taken: false },
  { id: 8, name: 'Zinc',       dose: '30 mg',   window: '21:00',    taken: false },
]

const SEED_WORKOUTS = [
  { day: 'MON', focus: 'Push', lift: 'Bench Press',   scheme: '5 × 5', load: '82.5 kg', done: false },
  { day: 'TUE', focus: 'Pull', lift: 'Weighted Pull-up',scheme: '4 × 8',load: '+12 kg', done: false },
  { day: 'WED', focus: 'Run',  lift: 'Zone-2 Run',    scheme: '45 min',load: '—',      done: false },
  { day: 'THU', focus: 'Legs', lift: 'Back Squat',    scheme: '5 × 5', load: '100 kg', done: false },
  { day: 'FRI', focus: 'Push', lift: 'Overhead Press',scheme: '5 × 5', load: '55 kg',  done: false },
  { day: 'SAT', focus: 'Pull', lift: 'Deadlift',      scheme: '3 × 5', load: '120 kg', done: false },
  { day: 'SUN', focus: 'Rest', lift: 'Mobility',      scheme: '20 min',load: '—',      done: false },
]

// ─── ATOMS ────────────────────────────────────────────────────────────────────
const Label = ({ children, style = {} }) => (
  <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: 1.6, color: C.muted,
    textTransform: 'uppercase', fontWeight: 500, ...style }}>{children}</span>
)

const Tag = ({ children, color = C.muted, filled = false }) => (
  <span style={{
    fontFamily: MONO, fontSize: 9, letterSpacing: 0.5, fontWeight: 600,
    padding: '2px 6px', border: `1px solid ${color}${filled ? '' : '33'}`,
    color: filled ? '#fff' : color, background: filled ? color : 'transparent',
    borderRadius: 2, textTransform: 'uppercase', whiteSpace: 'nowrap', display: 'inline-block',
  }}>{children}</span>
)

function Sparkline({ data, color = C.ink, height = 28 }) {
  const max = Math.max(...data), min = Math.min(...data), r = max - min || 1
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * 100},${100 - ((v - min) / r) * 85 - 7.5}`)
  const line = `M ${pts.join(' L ')}`
  const area = `${line} L 100,100 L 0,100 Z`
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: '100%', height, display: 'block' }}>
      <path d={area} fill={color} opacity={0.07} />
      <path d={line} fill="none" stroke={color} strokeWidth={1.5} vectorEffect="non-scaling-stroke"
        strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts.at(-1).split(',')[0]} cy={pts.at(-1).split(',')[1]} r="2"
        fill={color} vectorEffect="non-scaling-stroke" />
    </svg>
  )
}

function ProgressBar({ value, max, color = C.ink }) {
  const pct = Math.min((value / max) * 100, 100)
  return (
    <div style={{ height: 3, background: C.ruleSoft, borderRadius: 2, overflow: 'hidden', marginTop: 8 }}>
      <div style={{ height: '100%', width: `${pct}%`, background: color, transition: 'width 600ms ease' }} />
    </div>
  )
}

// ─── SECTION HEADER ──────────────────────────────────────────────────────────
function SectionHeader({ eyebrow, title }) {
  return (
    <div style={{ paddingBottom: 20, borderBottom: `1.5px solid ${C.ink}`, marginBottom: 20 }}>
      <Label>{eyebrow}</Label>
      <h1 style={{ fontFamily: SERIF, fontSize: 34, fontWeight: 400, color: C.ink,
        letterSpacing: -1, margin: '6px 0 0', lineHeight: 1.05 }}>{title}</h1>
    </div>
  )
}

// ─── TODAY ────────────────────────────────────────────────────────────────────
function Today({ goals, setGoals, water, setWater }) {
  const [newGoal, setNewGoal] = useState('')
  const done = goals.filter(g => g.done).length
  const pct = goals.length ? Math.round((done / goals.length) * 100) : 0
  const dateStr = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })

  function addGoal() {
    if (!newGoal.trim()) return
    setGoals(g => [...g, { id: Date.now(), text: newGoal.trim(), done: false, priority: 'P1', cat: 'Task' }])
    setNewGoal('')
  }

  return (
    <div>
      <SectionHeader eyebrow={dateStr} title="Today." />

      {/* Score card */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '20px 20px 16px', marginBottom: 16 }}>
        <Label>Daily Score</Label>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, margin: '8px 0 4px' }}>
          <span style={{ fontFamily: SERIF, fontSize: 72, fontWeight: 400, color: C.ink, lineHeight: 1, letterSpacing: -3 }}>{pct}</span>
          <span style={{ fontFamily: SERIF, fontSize: 28, color: C.muted, marginBottom: 10, fontStyle: 'italic' }}>/100</span>
        </div>
        <ProgressBar value={done} max={goals.length || 1} />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
          <span style={{ fontFamily: MONO, fontSize: 10, color: C.muted }}>{done}/{goals.length} complete</span>
          <Tag color={pct >= 80 ? C.positive : pct >= 50 ? C.amber : C.accent}
            filled>{pct >= 80 ? 'ON TRACK' : pct >= 50 ? 'IN PROGRESS' : 'BEHIND'}</Tag>
        </div>
      </div>

      {/* Water */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px', marginBottom: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Droplets size={14} color={C.muted} />
            <Label>Hydration</Label>
          </div>
          <span style={{ fontFamily: MONO, fontSize: 11, color: C.ink, fontWeight: 500 }}>{water}/8</span>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {Array(8).fill(0).map((_, i) => (
            <div key={i} onClick={() => setWater(w => i < w ? w - 1 : w + 1)} style={{
              flex: 1, height: 32, background: i < water ? C.ink : 'transparent',
              border: `1px solid ${i < water ? C.ink : C.mutedSoft}`,
              cursor: 'pointer', transition: 'background 150ms', borderRadius: 3,
            }} />
          ))}
        </div>
      </div>

      {/* Goals */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px', marginBottom: 16 }}>
        <Label style={{ display: 'block', marginBottom: 14 }}>Commitments</Label>
        {goals.map((g, i) => (
          <div key={g.id} onClick={() => setGoals(gs => gs.map(x => x.id === g.id ? { ...x, done: !x.done } : x))}
            style={{
              display: 'flex', alignItems: 'flex-start', gap: 12, padding: '12px 0',
              borderTop: i === 0 ? `1px solid ${C.rule}` : `1px solid ${C.ruleSoft}`,
              cursor: 'pointer',
            }}>
            <div style={{ marginTop: 2 }}>
              {g.done
                ? <CheckCircle2 size={16} strokeWidth={1.6} color={C.positive} />
                : <Circle size={16} strokeWidth={1.4} color={C.mutedSoft} />}
            </div>
            <span style={{
              flex: 1, fontFamily: FONT, fontSize: 14, color: g.done ? C.muted : C.ink,
              textDecoration: g.done ? 'line-through' : 'none', textDecorationColor: C.mutedSoft,
              lineHeight: 1.4,
            }}>{g.text}</span>
            <Tag color={g.priority === 'P0' ? C.accent : g.priority === 'P1' ? C.amber : C.muted}>{g.priority}</Tag>
          </div>
        ))}
        {/* Add goal */}
        <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 12, borderTop: `1px solid ${C.rule}` }}>
          <input
            value={newGoal} onChange={e => setNewGoal(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addGoal()}
            placeholder="Add a commitment…"
            style={{
              flex: 1, background: 'transparent', border: 'none', outline: 'none',
              fontFamily: SERIF, fontStyle: 'italic', fontSize: 14, color: C.ink,
            }}
          />
          <button onClick={addGoal} style={{
            background: C.ink, border: 'none', borderRadius: 4, width: 28, height: 28,
            display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
          }}>
            <Plus size={14} color="#fff" />
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── HEALTH ──────────────────────────────────────────────────────────────────
function Health({ supps, setSupps, workouts, setWorkouts, stats, setStats }) {
  return (
    <div>
      <SectionHeader eyebrow="Body & Recovery" title="Health." />

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
        {[
          { label: 'Weight', field: 'weight', unit: 'kg', spark: [76.4, 77.0, 77.5, 77.8, 78.0, 78.3, 78.5] },
          { label: 'Sleep', field: 'sleep', unit: 'h',   spark: [6.8, 7.2, 7.0, 7.5, 7.3, 7.6, 7.4] },
        ].map(s => (
          <div key={s.field} style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '14px 16px' }}>
            <Label>{s.label}</Label>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, margin: '6px 0 10px' }}>
              <input
                value={stats[s.field] ?? ''} onChange={e => setStats(st => ({ ...st, [s.field]: e.target.value }))}
                style={{ fontFamily: SERIF, fontSize: 32, fontWeight: 400, color: C.ink,
                  letterSpacing: -1, background: 'transparent', border: 'none', outline: 'none', width: '80px' }}
              />
              <span style={{ fontFamily: MONO, fontSize: 11, color: C.muted }}>{s.unit}</span>
            </div>
            <Sparkline data={s.spark} />
          </div>
        ))}
      </div>

      {/* Supplements */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px', marginBottom: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <Label>Supplementation</Label>
          <span style={{ fontFamily: MONO, fontSize: 10, color: C.ink, fontWeight: 600 }}>
            {supps.filter(s => s.taken).length}/{supps.length}
          </span>
        </div>
        {supps.map((s, i) => (
          <div key={s.id} onClick={() => setSupps(ss => ss.map(x => x.id === s.id ? { ...x, taken: !x.taken } : x))}
            style={{
              display: 'grid', gridTemplateColumns: '20px 1fr auto auto', gap: 12,
              alignItems: 'center', padding: '11px 0', cursor: 'pointer',
              borderTop: `1px solid ${i === 0 ? C.rule : C.ruleSoft}`,
            }}>
            <div style={{
              width: 16, height: 16, border: `1.5px solid ${s.taken ? C.positive : C.mutedSoft}`,
              background: s.taken ? C.positive : 'transparent', borderRadius: 3,
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              {s.taken && <span style={{ color: '#fff', fontSize: 10, fontWeight: 800, lineHeight: 1 }}>✓</span>}
            </div>
            <span style={{ fontFamily: FONT, fontSize: 14, color: s.taken ? C.muted : C.ink,
              textDecoration: s.taken ? 'line-through' : 'none', textDecorationColor: C.mutedSoft }}>{s.name}</span>
            <span style={{ fontFamily: MONO, fontSize: 11, color: C.muted }}>{s.dose}</span>
            <span style={{ fontFamily: MONO, fontSize: 10, color: C.muted }}>{s.window}</span>
          </div>
        ))}
      </div>

      {/* Workouts */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <Dumbbell size={13} color={C.muted} />
          <Label>Training Week</Label>
        </div>
        {workouts.map((w, i) => (
          <div key={i} onClick={() => setWorkouts(ws => ws.map((x, j) => j === i ? { ...x, done: !x.done } : x))}
            style={{
              display: 'grid', gridTemplateColumns: '36px 1fr 50px', gap: 10, alignItems: 'center',
              padding: '11px 0', borderTop: `1px solid ${i === 0 ? C.rule : C.ruleSoft}`, cursor: 'pointer',
            }}>
            <span style={{ fontFamily: MONO, fontSize: 10, color: C.ink, fontWeight: 600, letterSpacing: 1 }}>{w.day}</span>
            <div>
              <span style={{ fontFamily: FONT, fontSize: 13, color: w.done ? C.muted : C.ink,
                textDecoration: w.done ? 'line-through' : 'none', textDecorationColor: C.mutedSoft }}>{w.lift}</span>
              <div style={{ fontFamily: MONO, fontSize: 10, color: C.muted, marginTop: 1 }}>{w.scheme} · {w.load}</div>
            </div>
            <Tag color={w.focus === 'Push' ? C.accent : w.focus === 'Pull' ? C.positive : w.focus === 'Legs' ? C.amber : C.muted}
              filled={w.done}>{w.done ? 'DONE' : w.focus}</Tag>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── BRAND ───────────────────────────────────────────────────────────────────
function Brand({ brand, setBrand }) {
  const SPARKS = {
    followers: [42, 43, 44.5, 45.5, 46, 47, 48.2],
    views:     [800, 1050, 1310, 1650, 1820, 1960, 2100],
  }

  const automations = [
    { name: 'TikTok Clipper',     state: 'RUNNING', out: '+$340' },
    { name: 'IG Highlight Poster',state: 'IDLE',    out: '+$120' },
    { name: 'YT Shorts Pipeline', state: 'RUNNING', out: '+$210' },
    { name: 'Twitter / X',        state: 'PAUSED',  out: '+$60'  },
  ]

  return (
    <div>
      <SectionHeader eyebrow="Distribution & Reach" title="Brand." />

      {/* Metrics row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
        {[
          { label: 'TikTok Followers', field: 'followers', unit: 'k', spark: SPARKS.followers },
          { label: '30-day Views',     field: 'views',     unit: 'k', spark: SPARKS.views },
        ].map(m => (
          <div key={m.field} style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '14px 16px' }}>
            <Label>{m.label}</Label>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, margin: '6px 0 10px' }}>
              <input
                value={brand[m.field] ?? ''}
                onChange={e => setBrand(b => ({ ...b, [m.field]: e.target.value }))}
                style={{ fontFamily: SERIF, fontSize: 32, fontWeight: 400, color: C.ink,
                  letterSpacing: -1, background: 'transparent', border: 'none', outline: 'none', width: '80px' }}
              />
              <span style={{ fontFamily: MONO, fontSize: 11, color: C.muted }}>{m.unit}</span>
            </div>
            <Sparkline data={m.spark} />
          </div>
        ))}
      </div>

      {/* Posts goal */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px', marginBottom: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Label>Posts this week</Label>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <button onClick={() => setBrand(b => ({ ...b, posts: Math.max(0, (b.posts || 0) - 1) }))}
              style={{ width: 28, height: 28, border: `1px solid ${C.rule}`, background: 'transparent',
                borderRadius: 4, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ color: C.ink, fontFamily: MONO, fontSize: 14 }}>−</span>
            </button>
            <span style={{ fontFamily: SERIF, fontSize: 28, fontWeight: 400, color: C.ink, letterSpacing: -0.5 }}>{brand.posts || 0}</span>
            <button onClick={() => setBrand(b => ({ ...b, posts: (b.posts || 0) + 1 }))}
              style={{ width: 28, height: 28, border: `1px solid ${C.rule}`, background: 'transparent',
                borderRadius: 4, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ color: C.ink, fontFamily: MONO, fontSize: 14 }}>+</span>
            </button>
          </div>
        </div>
        <ProgressBar value={brand.posts || 0} max={7} />
        <span style={{ fontFamily: MONO, fontSize: 10, color: C.muted, marginTop: 4, display: 'block' }}>GOAL: 7 per week</span>
      </div>

      {/* Automations */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <Label>Automation Estate</Label>
          <Tag color={C.accent} filled>AUTO</Tag>
        </div>
        {automations.map((a, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0',
            borderTop: `1px solid ${i === 0 ? C.rule : C.ruleSoft}`,
          }}>
            <span style={{ fontFamily: FONT, fontSize: 14, color: C.ink }}>{a.name}</span>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span style={{ fontFamily: MONO, fontSize: 11, color: C.positive, fontWeight: 600 }}>{a.out}</span>
              <Tag color={a.state === 'RUNNING' ? C.positive : a.state === 'IDLE' ? C.amber : C.muted}
                filled={a.state === 'RUNNING'}>{a.state}</Tag>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── FINANCE ─────────────────────────────────────────────────────────────────
function Finance({ finance, setFinance }) {
  const SPARK_MRR = [3800, 4100, 4300, 4560, 4800, 5200, 5760]

  const streams = [
    { key: 'partnerships', label: 'Brand partnerships' },
    { key: 'creator',      label: 'Creator fund'       },
    { key: 'clipping',     label: 'Clipping income'    },
    { key: 'course',       label: 'Course sales'       },
  ]

  const total = streams.reduce((sum, s) => sum + (parseFloat(finance[s.key]) || 0), 0)

  return (
    <div>
      <SectionHeader eyebrow="Cash & Compounding" title="Finance." />

      {/* MRR hero */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '20px 20px 16px', marginBottom: 16 }}>
        <Label>Monthly Revenue</Label>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, margin: '8px 0 4px' }}>
          <span style={{ fontFamily: SERIF, fontSize: 64, fontWeight: 400, color: C.ink,
            lineHeight: 1, letterSpacing: -2.5 }}>${total.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 14 }}>
          <ArrowUpRight size={12} color={C.positive} />
          <span style={{ fontFamily: MONO, fontSize: 10.5, color: C.positive }}>tracked across 4 streams</span>
        </div>
        <Sparkline data={SPARK_MRR} height={42} />
      </div>

      {/* Revenue streams (editable) */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px', marginBottom: 16 }}>
        <Label style={{ display: 'block', marginBottom: 14 }}>Revenue Streams</Label>
        {streams.map((s, i) => (
          <div key={s.key} style={{ padding: '12px 0', borderTop: `1px solid ${i === 0 ? C.rule : C.ruleSoft}`,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontFamily: FONT, fontSize: 14, color: C.ink }}>{s.label}</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <span style={{ fontFamily: MONO, fontSize: 13, color: C.muted }}>$</span>
              <input
                value={finance[s.key] ?? ''}
                onChange={e => setFinance(f => ({ ...f, [s.key]: e.target.value }))}
                placeholder="0"
                style={{ fontFamily: MONO, fontSize: 14, fontWeight: 600, color: C.ink,
                  background: 'transparent', border: 'none', outline: 'none', textAlign: 'right', width: 80 }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Capital targets */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px' }}>
        <Label style={{ display: 'block', marginBottom: 14 }}>Capital Targets</Label>
        {[
          { label: 'Monthly target', current: total, goal: 8000 },
          { label: 'Emergency fund', current: parseFloat(finance.emergency) || 0, goal: 10000, editable: 'emergency' },
          { label: 'Investments',    current: parseFloat(finance.invest) || 0,    goal: 5000,  editable: 'invest' },
        ].map((g, i) => {
          const pct = Math.min((g.current / g.goal) * 100, 100)
          return (
            <div key={i} style={{ padding: '14px 0', borderTop: `1px solid ${i === 0 ? C.rule : C.ruleSoft}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <span style={{ fontFamily: FONT, fontSize: 13, color: C.ink }}>{g.label}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  {g.editable && <span style={{ fontFamily: MONO, fontSize: 11, color: C.muted }}>$</span>}
                  {g.editable
                    ? <input value={finance[g.editable] ?? ''} onChange={e => setFinance(f => ({ ...f, [g.editable]: e.target.value }))}
                        placeholder="0"
                        style={{ fontFamily: MONO, fontSize: 12, fontWeight: 600, color: C.ink,
                          background: 'transparent', border: 'none', outline: 'none', textAlign: 'right', width: 70 }} />
                    : <span style={{ fontFamily: MONO, fontSize: 12, fontWeight: 600, color: C.ink }}>
                        ${g.current.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                      </span>
                  }
                  <span style={{ fontFamily: MONO, fontSize: 11, color: C.muted }}> / ${g.goal.toLocaleString()}</span>
                </div>
              </div>
              <ProgressBar value={g.current} max={g.goal} color={pct >= 100 ? C.positive : C.ink} />
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ─── LOG ─────────────────────────────────────────────────────────────────────
function Log({ logs, setLogs }) {
  const [input, setInput] = useState('')
  const [tag, setTag] = useState('Note')
  const tags = ['Note', 'Win', 'Idea', 'Block']

  function addLog() {
    if (!input.trim()) return
    setLogs(l => [{
      id: Date.now(), text: input.trim(), tag,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    }, ...l])
    setInput('')
  }

  return (
    <div>
      <SectionHeader eyebrow="Running Record" title="Log." />

      {/* Composer */}
      <div style={{ background: C.paperCard, border: `1px solid ${C.rule}`, borderRadius: 12, padding: '16px 20px', marginBottom: 16 }}>
        <textarea
          value={input} onChange={e => setInput(e.target.value)}
          placeholder="What happened. What you noticed. What you're thinking."
          rows={3}
          style={{
            width: '100%', background: 'transparent', border: 'none', outline: 'none', resize: 'none',
            fontFamily: SERIF, fontStyle: 'italic', fontSize: 15, color: C.ink, lineHeight: 1.55,
          }}
        />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          paddingTop: 12, borderTop: `1px solid ${C.rule}`, marginTop: 8 }}>
          <div style={{ display: 'flex', gap: 6 }}>
            {tags.map(t => (
              <button key={t} onClick={() => setTag(t)} style={{
                fontFamily: MONO, fontSize: 9, letterSpacing: 1, fontWeight: 600, padding: '4px 8px',
                border: `1px solid ${tag === t ? C.ink : C.mutedSoft}`,
                background: tag === t ? C.ink : 'transparent',
                color: tag === t ? '#fff' : C.muted,
                cursor: 'pointer', borderRadius: 3, textTransform: 'uppercase',
              }}>{t}</button>
            ))}
          </div>
          <button onClick={addLog} style={{
            background: C.ink, border: 'none', borderRadius: 6, padding: '8px 16px',
            color: '#fff', fontFamily: MONO, fontSize: 10, letterSpacing: 1, fontWeight: 600, cursor: 'pointer',
          }}>LOG IT</button>
        </div>
      </div>

      {/* Entries */}
      {logs.length === 0 && (
        <p style={{ fontFamily: SERIF, fontStyle: 'italic', fontSize: 15, color: C.muted,
          textAlign: 'center', marginTop: 40 }}>Nothing logged yet today.</p>
      )}
      {logs.map(l => (
        <div key={l.id} style={{ background: C.paperCard, border: `1px solid ${C.rule}`,
          borderRadius: 12, padding: '16px 20px', marginBottom: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <Tag color={l.tag === 'Win' ? C.positive : l.tag === 'Block' ? C.accent : l.tag === 'Idea' ? C.amber : C.muted}>{l.tag}</Tag>
            <span style={{ fontFamily: MONO, fontSize: 10, color: C.muted }}>{l.date} · {l.time}</span>
          </div>
          <p style={{ fontFamily: SERIF, fontSize: 15, color: C.ink, lineHeight: 1.6, margin: 0 }}>{l.text}</p>
          <button onClick={() => setLogs(ls => ls.filter(x => x.id !== l.id))}
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', marginTop: 10,
              display: 'flex', alignItems: 'center', gap: 4, padding: 0 }}>
            <Trash2 size={12} color={C.mutedSoft} />
            <span style={{ fontFamily: MONO, fontSize: 9, color: C.mutedSoft, letterSpacing: 0.8 }}>DELETE</span>
          </button>
        </div>
      ))}
    </div>
  )
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab]           = useState('today')
  const [goals, setGoals]       = usePersist('goals',    SEED_GOALS)
  const [supps, setSupps]       = usePersist('supps',    SEED_SUPPS)
  const [workouts, setWorkouts] = usePersist('workouts', SEED_WORKOUTS)
  const [water, setWater]       = usePersist('water',    0)
  const [stats, setStats]       = usePersist('stats',    { weight: '78.5', sleep: '7.4' })
  const [brand, setBrand]       = usePersist('brand',    { followers: '48.2', views: '2100', posts: 0 })
  const [finance, setFinance]   = usePersist('finance',  { partnerships: '3500', creator: '1240', clipping: '730', course: '290', emergency: '4200', invest: '2100' })
  const [logs, setLogs]         = usePersist('logs',     [])

  // Reset daily tasks at midnight
  useEffect(() => {
    const lastDate = localStorage.getItem('lastDate')
    const today = new Date().toDateString()
    if (lastDate !== today) {
      setGoals(gs => gs.map(g => ({ ...g, done: false })))
      setSupps(ss => ss.map(s => ({ ...s, taken: false })))
      setWater(0)
      localStorage.setItem('lastDate', today)
    }
  }, [])

  const TABS = [
    { id: 'today',   label: 'Today',   Icon: Home       },
    { id: 'health',  label: 'Health',  Icon: Heart      },
    { id: 'brand',   label: 'Brand',   Icon: Briefcase  },
    { id: 'finance', label: 'Finance', Icon: DollarSign },
    { id: 'log',     label: 'Log',     Icon: BookOpen   },
  ]

  return (
    <div style={{ height: '100dvh', display: 'flex', flexDirection: 'column',
      background: C.paper, fontFamily: FONT, overflowX: 'hidden' }}>
      <style>{`
        * { box-sizing: border-box; }
        input, textarea { -webkit-appearance: none; }
        input[type=number]::-webkit-inner-spin-button { -webkit-appearance: none; }
        @keyframes fadeUp { from { opacity:0; transform: translateY(8px) } to { opacity:1; transform: translateY(0) } }
        .page-enter { animation: fadeUp 240ms ease; }
        ::placeholder { color: ${C.mutedSoft}; font-style: italic; }
      `}</style>

      {/* Scrollable content */}
      <main className="page-enter" key={tab} style={{
        flex: 1, overflowY: 'auto', padding: '32px 20px 0',
        WebkitOverflowScrolling: 'touch',
      }}>
        {tab === 'today'   && <Today goals={goals} setGoals={setGoals} water={water} setWater={setWater} />}
        {tab === 'health'  && <Health supps={supps} setSupps={setSupps} workouts={workouts} setWorkouts={setWorkouts} stats={stats} setStats={setStats} />}
        {tab === 'brand'   && <Brand brand={brand} setBrand={setBrand} />}
        {tab === 'finance' && <Finance finance={finance} setFinance={setFinance} />}
        {tab === 'log'     && <Log logs={logs} setLogs={setLogs} />}
        <div style={{ height: 100 }} />
      </main>

      {/* Bottom tab bar */}
      <nav style={{
        display: 'flex', background: C.paperDeep, borderTop: `1px solid ${C.rule}`,
        paddingBottom: 'env(safe-area-inset-bottom)',
        position: 'sticky', bottom: 0, zIndex: 100,
      }}>
        {TABS.map(({ id, label, Icon }) => {
          const active = tab === id
          return (
            <button key={id} onClick={() => setTab(id)} style={{
              flex: 1, padding: '10px 0 8px', border: 'none', background: 'transparent',
              cursor: 'pointer', display: 'flex', flexDirection: 'column',
              alignItems: 'center', gap: 4, position: 'relative',
            }}>
              {active && (
                <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
                  width: 24, height: 2, background: C.accent }} />
              )}
              <Icon size={18} strokeWidth={active ? 2 : 1.4}
                color={active ? C.ink : C.muted} />
              <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: 0.8,
                color: active ? C.ink : C.muted, fontWeight: active ? 600 : 400 }}>
                {label.toUpperCase()}
              </span>
            </button>
          )
        })}
      </nav>
    </div>
  )
}
